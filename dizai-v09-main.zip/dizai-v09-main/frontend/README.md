# DizAí v0.9 – Frontend

## Install
1. `npm install`
2. `npm run dev`
3. Frontend startar på http://localhost:5173 (proxyar mot backend på :3001)

- Byt profil (Johan/Petra)
- Spela upp referens (TTS)
- Spela in och analysera
- Se feedback och nästa/prev-mening

*Du måste köra backend samtidigt!*
